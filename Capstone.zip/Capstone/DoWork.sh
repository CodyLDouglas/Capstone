./Code.sh
./Paper.sh