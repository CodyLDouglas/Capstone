./DoOutline.sh > DoOutline.out
 open outline.pdf