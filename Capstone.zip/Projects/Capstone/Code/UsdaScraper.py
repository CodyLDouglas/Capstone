import requests

URL = "https://www.marketnews.usda.gov/"
page = requests.get(URL)
