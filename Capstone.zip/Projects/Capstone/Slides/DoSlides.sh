./CompileSlides.sh

# open slides.pdf