rm Data/cleanedData/boxedDataset.csv Data/cleanedData/fedCattleDataset.csv Data/cleanedData/feederSteers.csv
rm -rf Figures/timeSeriesPlots Figures/chuckCcfs Figures/acfs 
mkdir Figures/timeSeriesPlots Figures/chuckCcfs Figures/acfs 
chmod +x Code/checkLibraries.R
chmod +x Code/cattleCleaning.R
chmod +x Code/boxedCleaning.R
chmod +x Code/createDatabase.sql
chmod +x Code/modelDataSelection.sql
chmod +x Code/dataCompilation.R
chmod +x Code/miscPlots.R
chmod +x Code/summaryStats.R
chmod +x Code/acfs.R
chmod +x Code/linearPriceModeling.R
chmod +x Code/arimaPriceModeling.R
chmod +x Data/rawData/rawFedBulls.csv
chmod +x Data/rawData/rawFedCows.csv
chmod +x Data/rawData/rawFedSteer.csv
chmod +x Data/rawData/rawFedHeifers.csv
chmod +x Data/rawData/rawFeederSteers.csv
chmod +x Data/rawData/rawFormulatedChoiceBoxed.csv
chmod +x Data/rawData/rawFormulatedSelectBoxed.csv
chmod +x Data/rawData/rawNegotiatedChoiceBoxed.csv
chmod +x Data/rawData/rawNegotiatedSelectBoxed.csv
chmod +x Data/rawData/rawCornPrices.csv
chmod +x Data/economicData/chickenPrices.csv
chmod +x Data/economicData/consumerExpenditures.csv
chmod +x Data/economicData/CPI.csv
chmod +x Data/economicData/porkChopPrices.csv

echo "Checking status of required libraries, installing if necessary."
Rscript Code/checkLibraries.R
echo "Beginning code. First, fed cattle data reading, cleaning, and combining."
Rscript Code/cattleCleaning.R
echo "Now, boxed beef."
Rscript Code/boxedCleaning.R
echo "Creating SQL database."
rm Data/database.db
chmod +x Data/cleanedData/boxedDataset.csv
chmod +x Data/cleanedData/fedCattleDataset.csv
chmod +x Data/cleanedData/feederSteers.csv
sqlite3 Data/database.db < Code/createDatabase.sql
echo "Extracting relevant data from database."
sqlite3 Data/database.db < Code/modelDataSelection.sql
Rscript Code/dataCompilation.R
echo "Making miscellaneous plots and summary statistics."
Rscript Code/miscPlots.R
Rscript Code/summaryStats.R
Rscript Code/acfs.R
rm Rplots.pdf
echo "Beginning Modeling Process."
Rscript Code/linearPriceModeling.R
echo "Linear Price Modeling Done."
echo "Beginning ARIMA modeling, this may take a few minutes."
#Rscript Code/arimaPriceModeling.R
echo "Arima Modeling Done. Beginning Composite Model Creation"
Rscript Code/combinedModel.R
echo "Code Done."
