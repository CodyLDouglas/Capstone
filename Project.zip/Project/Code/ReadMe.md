=-=-=-=-=-=-=-=-=-=-=-=-=-=
Welcome to the Code folder
=-=-=-=-=-=-=-=-=-=-=-=-=-=

In this folder you will see all the code used for this project. This ReadMe will go over what these scripts do and their outputs, in the order they are called.

checkLibraries.R -
		This script checks if the R packages xts, forecast, dynlm, and tseries. xts and tseries are used for better time series object manipulation. Forecast provides the ARIMA function used in arimaPriceModeling.R and dynlm allows the use of lagged variables in a linear regression.

cattleCleaning.R and boxedCleaning.R -
		Cleans the raw cattle and boxed beef data files adding a standardized quality variable for the fed cattle data.

createDatabase.sql - 
		Creates the SQL database file, storing all rows from the raw fed and feeder files, boxed beef file, and feedstuff corn auction results.

modelDataSelection.sql -
		Selects and aggregates the specific data needed for this project. Including the dependent variable, chuck beef, prices and quantities. Along with this, the script selects feeder and fed prices, total heads sold, sell weight, and quality. Lastly, it selects the feedstuff corn prices. These queries are stored as seperate csv files in the Data folder denoted by either ...Results.csv or ...Prices.csv. 

dataCompilation.R -
		Reads and combines the data files created from the previous script and merges with economic indicator data stored in seperate csv files. Full combined dataset stored in the Data folder, titled fullDataset.csv.

miscPlots.R - 
		As the name suggests, this script creates miscellaneous time series plots required for the paper. These plots are stored in the sub folder Figures/timeSeriesPlots. 

acfs.R - 
		This script is where the modeling process really begins. The first differences of all the model variables are calculted, then these are used to calculate the acfs and pacfs of the variables and the correlated lags with the chuck price differences. These acfs, pacfs, and ccfs are used to determine the values in the ARIMA and linear regression models. These are stored in the subfolder Figures/acfs and Figures/chuckCcfs. 

linearPriceModeling.R -
		Creates a linear model that projects wholesale chuck beef prices onto the lags of the dependent variables, using the lags identified by the ccf plots produced previously.

arimaPriceModeling.R -
		Creates an ARIMA model of the wholesale chuck beef prices against the dependent variables. The orders of p and q are determined from the ACF and PACF plots produced previously.