library(xts)



fullDataset = read.csv("Data/fullDataset.csv")

chuckData = fullDataset[,1:3]
diffs = diff(chuckData$Weighted.Average)


chuckTS = ts(xts(chuckData[,3],order.by=as.Date(chuckData[,1],"%Y-%m-%d")))
chuckDiffs= ts(xts(diffs,order.by=as.Date(chuckData[-1,1],"%Y-%m-%d")))


png(filename = "Figures/acfs/chuckACF.png")
plot(acf(chuckTS, lag.max=60)[2:60], main="ACF of Chuck")
dev.off()
png(filename = "Figures/acfs/chuckPACF.png")
plot(pacf(chuckTS, lag.max=60)[2:60], main="PACF of Chuck")
dev.off()


png(filename = "Figures/acfs/chuckDiffsACF.png")
plot(acf(chuckDiffs, lag.max=60)[2:60], main="ACF of Chuck Diffs")
dev.off()
png(filename = "Figures/acfs/chuckDiffsPACF.png")
plot(pacf(chuckDiffs, lag.max=60)[2:60], main="PACF of Chuck Diffs")
dev.off()


steersPriceDiffs = diff(fullDataset$Steers.Weighted.Average.Price)
heifersPriceDiffs = diff(fullDataset$Heifers.Weighted.Average.Price)
cowsPriceDiffs = diff(fullDataset$Cows.Weighted.Average.Price)
bullsPriceDiffs = diff(fullDataset$Bulls.Weighted.Average.Price)
feederPriceDiffs = diff(fullDataset$Feeder.Weighted.Average.Price)
steersHeadsDiffs = diff(fullDataset$Steers.Total.Heads)
heifersHeadsDiffs = diff(fullDataset$Heifers.Total.Heads)
cowsHeadsDiffs = diff(fullDataset$Cows.Total.Heads)
bullsHeadsDiffs = diff(fullDataset$Bulls.Total.Heads)
feederHeadsDiffs = diff(fullDataset$Feeder.Total.Heads)
chuckPriceDiffs = diff(fullDataset$Weighted.Average)
steersWeightDiffs = diff(fullDataset$Steers.Weighted.Average.Weight)
heifersWeightDiffs = diff(fullDataset$Heifers.Weighted.Average.Weight)
cowsWeightDiffs = diff(fullDataset$Cows.Weighted.Average.Weight)
bullsWeightDiffs = diff(fullDataset$Bulls.Weighted.Average.Weight)
feederWeightDiffs = diff(fullDataset$Feeder.Weighted.Average.Weight)




cpiDiffs = diff(fullDataset$cpi)
porkDiffs = diff(fullDataset$pork)
chickenDiffs = diff(fullDataset$chicken)
expendituresDiffs = diff(fullDataset$expenditures)
cornDiffs = diff(fullDataset$Corn.Price)

fullDiffs = data.frame(Report.Date=fullDataset[-1,1],chuckPriceDiffs,steersPriceDiffs,heifersPriceDiffs,cowsPriceDiffs,bullsPriceDiffs,feederPriceDiffs,
					steersHeadsDiffs,heifersHeadsDiffs,cowsHeadsDiffs,bullsHeadsDiffs,feederHeadsDiffs,steersWeightDiffs,heifersWeightDiffs,cowsWeightDiffs,bullsWeightDiffs,feederWeightDiffs,
					porkDiffs,chickenDiffs,cornDiffs)
write.csv(fullDiffs,"Data/fullDiffs.csv",row.names=FALSE)


steersPriceCorrs = ccf(steersPriceDiffs,chuckPriceDiffs,lag=52)
heifersPriceCorrs = ccf(heifersPriceDiffs,chuckPriceDiffs,lag=52)
cowsPriceCorrs = ccf(cowsPriceDiffs,chuckPriceDiffs,lag=52)
bullsPriceCorrs = ccf(bullsPriceDiffs,chuckPriceDiffs,lag=52)
feederPriceCorrs = ccf(feederPriceDiffs, chuckPriceDiffs,lag=52)
steersHeadsCorrs = ccf(steersHeadsDiffs,chuckPriceDiffs,lag=52)
heifersHeadsCorrs = ccf(heifersHeadsDiffs,chuckPriceDiffs,lag=52)
cowsHeadsCorrs = ccf(cowsHeadsDiffs,chuckPriceDiffs,lag=52)
bullsHeadsCorrs = ccf(bullsHeadsDiffs,chuckPriceDiffs,lag=52)
feederHeadsCorrs = ccf(feederHeadsDiffs, chuckPriceDiffs,lag=52)

cpiCorrs = ccf(cpiDiffs, chuckPriceDiffs,lag=52)
porkCorrs = ccf(porkDiffs, chuckPriceDiffs,lag=52)
chickenCorrs = ccf(chickenDiffs, chuckPriceDiffs,lag=52)
expendituresCorrs = ccf(expendituresDiffs, chuckPriceDiffs,lag=52)
cornCorrs = ccf(cornDiffs, chuckPriceDiffs, lag=52)

steersHeifers = ccf(steersPriceDiffs,heifersPriceDiffs,lag=52)
steersCows = ccf(steersPriceDiffs,cowsPriceDiffs,lag=52)
steersBulls = ccf(steersPriceDiffs,bullsPriceDiffs,lag=52)
heifersCows = ccf(heifersPriceDiffs,cowsPriceDiffs,lag=52)
heifersBulls = ccf(heifersPriceDiffs,bullsPriceDiffs,lag=52)
cowsBulls = ccf(cowsPriceDiffs,bullsPriceDiffs,lag=52)

steersFeeders = ccf(steersPriceDiffs,feederPriceDiffs,lag=52)
heifersFeeders = ccf(heifersPriceDiffs,feederPriceDiffs,lag=52)
cowsFeeders = ccf(cowsPriceDiffs,feederPriceDiffs,lag=52)
bullsFeeders = ccf(bullsPriceDiffs,feederPriceDiffs,lag=52)

steersPrice =data.frame(lag=steersPriceCorrs$lag,acf=steersPriceCorrs$acf)[1:53,]
heifersPrice =data.frame(lag=heifersPriceCorrs$lag,acf=heifersPriceCorrs$acf)[1:53,]
cowsPrice = data.frame(lag=cowsPriceCorrs$lag,acf=cowsPriceCorrs$acf)[1:53,]
bullsPrice = data.frame(lag=bullsPriceCorrs$lag,acf=bullsPriceCorrs$acf)[1:53,]
feederPrice = data.frame(lag=feederPriceCorrs$lag,acf=feederPriceCorrs$acf)[1:53,]
steersHeads =data.frame(lag=steersHeadsCorrs$lag,acf=steersHeadsCorrs$acf)[1:53,]
heifersHeads =data.frame(lag=heifersHeadsCorrs$lag,acf=heifersHeadsCorrs$acf)[1:53,]
cowsHeads = data.frame(lag=cowsHeadsCorrs$lag,acf=cowsHeadsCorrs$acf)[1:53,]
bullsHeads = data.frame(lag=bullsHeadsCorrs$lag,acf=bullsHeadsCorrs$acf)[1:53,]
feederHeads = data.frame(lag=feederHeadsCorrs$lag,acf=feederHeadsCorrs$acf)[1:53,]
cpi = data.frame(lag=cpiCorrs$lag,acf=cpiCorrs$acf)[1:53,]
pork = data.frame(lag=porkCorrs$lag,acf=porkCorrs$acf)[1:53,]
chicken = data.frame(lag=chickenCorrs$lag,acf=chickenCorrs$acf)[1:53,]
expenditures = data.frame(lag=expendituresCorrs$lag,acf=expendituresCorrs$acf)[1:53,]



cat("Steers Price ACFs \n")
tail(steersPrice[order(abs(steersPrice$acf)),],5)
cat("Heifers Price ACFs \n")
tail(heifersPrice[order(abs(heifersPrice$acf)),],5)
cat("Cows Price ACFs \n")
tail(cowsPrice[order(abs(cowsPrice$acf)),],5)
cat("Bulls Price ACFs \n")
tail(bullsPrice[order(abs(bullsPrice$acf)),],5)
cat("Feeder Price ACFs \n")
tail(feederPrice[order(abs(feederPrice$acf)),],5)
cat("Steers Head ACFs \n")
tail(steersHeads[order(abs(steersHeads$acf)),],5)
cat("Heifers Heads ACFs \n")
tail(heifersHeads[order(abs(heifersHeads$acf)),],5)
cat("Cows Heads ACFs \n")
tail(cowsHeads[order(abs(cowsHeads$acf)),],5)
cat("Bulls Heads ACFs \n")
tail(bullsHeads[order(abs(bullsHeads$acf)),],5)
cat("Feeder Heads ACFs \n")
tail(feederHeads[order(abs(feederHeads$acf)),],5)
cat("CPI ACFs \n")
tail(cpi[order(abs(cpi$acf)),],5)
cat("Pork ACFs \n")
tail(pork[order(abs(pork$acf)),],5)
cat("Chicken ACFs \n")
tail(chicken[order(abs(chicken$acf)),],5)
cat("Expenditures ACFs \n")
tail(expenditures[order(abs(expenditures$acf)),],5)

png(filename = "Figures/chuckCcfs/steersPriceACF.png")
plot(steersPriceCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Steers and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/heifersPriceACF.png")
plot(heifersPriceCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Heifers and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/cowsPriceACF.png")
plot(cowsPriceCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Cows and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/bullsPriceACF.png")
plot(bullsPriceCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Bulls and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/feederPriceACF.png")
plot(feederPriceCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Feeder Steers and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/steersHeadsACF.png")
plot(steersHeadsCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Steers Heads and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/heifersHeadsACF.png")
plot(heifersHeadsCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Heifers Heads and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/cowsHeadsACF.png")
plot(cowsHeadsCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Cows Heads and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/bullsHeadsACF.png")
plot(bullsHeadsCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Bulls Heads and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/feederHeadsACF.png")
plot(feederHeadsCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Feeder Steers Heads and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/cpiACF.png")
plot(cpiCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in CPI and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/porkACF.png")
plot(porkCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Retail Pork and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/chickenACF.png")
plot(chickenCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Retail Chicken and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/expendituresACF.png")
plot(expendituresCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Expenditures and Beef Prices")
dev.off()

png(filename = "Figures/chuckCcfs/cornACF.png")
plot(cornCorrs[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Expenditures and Corn Prices")
dev.off()

png(filename = "Figures/chuckCcfs/steersHeifersACF.png")
plot(steersHeifers[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Steers and Heifers Prices")
dev.off()

png(filename = "Figures/chuckCcfs/steersCowsACF.png")
plot(steersCows[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Steers and Cows Prices")
dev.off()

png(filename = "Figures/chuckCcfs/steersBullsACF.png")
plot(steersBulls[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Steers and Bulls Prices")
dev.off()

png(filename = "Figures/chuckCcfs/heifersCowsACF.png")
plot(heifersCows[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Heifers and Cows Prices")
dev.off()

png(filename = "Figures/chuckCcfs/heifersBullsACF.png")
plot(heifersBulls[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Heifers and Bulls Prices")
dev.off()

png(filename = "Figures/chuckCcfs/cowsBullsACF.png")
plot(cowsBulls[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Cows and Bulls Prices")
dev.off()

png(filename = "Figures/chuckCcfs/steersFeedersACF.png")
plot(steersFeeders[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter and Feeder Steers Prices")
dev.off()

png(filename = "Figures/chuckCcfs/heifersFeedersACF.png")
plot(heifersFeeders[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Heifers and Feeder Steers Prices")
dev.off()

png(filename = "Figures/chuckCcfs/cowsFeedersACF.png")
plot(cowsFeeders[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Cows and Feeder Steers Prices")
dev.off()

png(filename = "Figures/chuckCcfs/bullsFeedersACF.png")
plot(bullsFeeders[-c(0:52)], xlab="Lags",ylab="Correlations",main="Lagged Corrleations of Changes in Slaughter Bulls and Feeder Steers Prices")
dev.off()
