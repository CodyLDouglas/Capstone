library(xts)
library(forecast)
set.seed(1234)
fullDataset = read.csv("Data/fullDataset.csv")



testRows = fullDataset[(nrow(fullDataset)-52):nrow(fullDataset),]
valRows = fullDataset[(nrow(fullDataset)-208):(nrow(fullDataset)-53),]
trainRows = fullDataset[1:(nrow(fullDataset)-209),]
fullTrainRows = fullDataset[1:(nrow(fullDataset)-53),]



trainData = zoo(trainRows[,-1],order.by=as.Date(trainRows[,1],format="%Y-%m-%d"))
valData = zoo(valRows[,-1],order.by=as.Date(valRows[,1],format="%Y-%m-%d"))
fullTrainData = zoo(fullTrainRows[,-1],order.by=as.Date(fullTrainRows[,1],format="%Y-%m-%d"))
testData = zoo(testRows[,-1],order.by=as.Date(testRows[,1],format="%Y-%m-%d"))

xreg = as.matrix(cbind(trainRows$Steers.Weighted.Average.Price,trainRows$Heifers.Weighted.Average.Price,trainRows$Cows.Weighted.Average.Price,trainRows$Bulls.Weighted.Average.Price,trainRows$Feeders.Weighted.Average.Price,
						trainRows$Steers.Weighted.Average.Weight,trainRows$Heifers.Weighted.Average.Weight,trainRows$Cows.Weighted.Average.Weight,trainRows$Bulls.Weighted.Average.Weight,trainRows$Feeders.Weighted.Average.Weight,
						trainRows$Steers.Total.Heads,trainRows$Heifers.Total.Heads,trainRows$Cows.Total.Heads,trainRows$Bulls.Total.Heads,trainRows$Feeder.Total.Heads,trainRows$pork,trainRows$chicken,trainRows$Corn.Price))

fullxreg = as.matrix(cbind(fullTrainRows$Steers.Weighted.Average.Price,fullTrainRows$Heifers.Weighted.Average.Price,fullTrainRows$Cows.Weighted.Average.Price,fullTrainRows$Bulls.Weighted.Average.Price,fullTrainRows$Feeders.Weighted.Average.Price,
							fullTrainRows$Steers.Weighted.Average.Weight,fullTrainRows$Heifers.Weighted.Average.Weight,fullTrainRows$Cows.Weighted.Average.Weight,fullTrainRows$Bulls.Weighted.Average.Weight,fullTrainRows$Feeders.Weighted.Average.Weight,
							fullTrainRows$Steers.Total.Heads,fullTrainRows$Heifers.Total.Heads,fullTrainRows$Cows.Total.Heads,fullTrainRows$Bulls.Total.Heads,fullTrainRows$Feeder.Total.Heads,fullTrainRows$pork,fullTrainRows$chicken,fullTrainRows$Corn.Price))

valxreg = as.matrix(cbind(valRows$Steers.Weighted.Average.Price,valRows$Heifers.Weighted.Average.Price,valRows$Cows.Weighted.Average.Price,valRows$Bulls.Weighted.Average.Price,valRows$Feeders.Weighted.Average.Price,
							valRows$Steers.Weighted.Average.Weight,valRows$Heifers.Weighted.Average.Weight,valRows$Cows.Weighted.Average.Weight,valRows$Bulls.Weighted.Average.Weight,valRows$Feeders.Weighted.Average.Weight,
							valRows$Steers.Total.Heads,valRows$Heifers.Total.Heads,valRows$Cows.Total.Heads,valRows$Bulls.Total.Heads,valRows$Feeder.Total.Heads,valRows$pork,valRows$chicken,valRows$Corn.Price))

newxreg = as.matrix(cbind(testRows$Steers.Weighted.Average.Price,testRows$Heifers.Weighted.Average.Price,testRows$Cows.Weighted.Average.Price,testRows$Bulls.Weighted.Average.Price,testRows$Feeders.Weighted.Average.Price,
							testRows$Steers.Weighted.Average.Weight,testRows$Heifers.Weighted.Average.Weight,testRows$Cows.Weighted.Average.Weight,testRows$Bulls.Weighted.Average.Weight,testRows$Feeders.Weighted.Average.Weight,
							testRows$Steers.Total.Heads,testRows$Heifers.Total.Heads,testRows$Cows.Total.Heads,testRows$Bulls.Total.Heads,testRows$Feeder.Total.Heads,testRows$pork,testRows$chicken,testRows$Corn.Price))


#model.9 = Arima(trainRows$Weighted.Average,order=c(0,1,9),seasonal=list(order=c(1,1,1),period=52L))
#model.10 = Arima(trainRows$Weighted.Average,order=c(0,1,10),seasonal=list(order=c(1,1,1),period=52L))
#model.11 = Arima(trainRows$Weighted.Average,order=c(0,1,11),seasonal=list(order=c(1,1,1),period=52L))
#model.12 = Arima(trainRows$Weighted.Average,order=c(0,1,12),seasonal=list(order=c(1,1,1),period=52L))
#modelFull.9 = Arima(trainRows$Weighted.Average,order=c(0,1,9),seasonal=list(order=c(1,1,1),period=52L),xreg=xreg)
#modelFull.10 = Arima(trainRows$Weighted.Average,order=c(0,1,10),seasonal=list(order=c(1,1,1),period=52L),xreg=xreg)
modelFull.11 = Arima(trainRows$Weighted.Average,order=c(0,1,11),seasonal=list(order=c(1,1,1),period=52L),xreg=xreg)
#modelFull.12 = Arima(trainRows$Weighted.Average,order=c(0,1,12),seasonal=list(order=c(1,1,1),period=52L),xreg=xreg)


#predictions.9 = predict(model.9,n.ahead=156)
#predictions.10 = predict(model.10,n.ahead=156)
#predictions.11 = predict(model.11,n.ahead=156)
#predictions.12 = predict(model.12,n.ahead=156)
#predictionsFull.9 = predict(modelFull.9,newxreg=valxreg,n.ahead=156)
#predictionsFull.10 = predict(modelFull.10,newxreg=valxreg,n.ahead=156)
predictionsFull.11 = predict(modelFull.11,newxreg=valxreg,n.ahead=156)
#predictionsFull.12 = predict(modelFull.12,newxreg=valxreg,n.ahead=156)
write.csv(predictionsFull.11,"Data/predictions/valFullArimaPredictions.csv",row.names=FALSE)

#rmse.9 = sqrt(mean((valData$Weighted.Average - as.vector(predictions.9$pred))^2))
#rmse.10 = sqrt(mean((valData$Weighted.Average - as.vector(predictions.10$pred))^2))
#rmse.11 = sqrt(mean((valData$Weighted.Average - as.vector(predictions.11$pred))^2))
#rmse.12 = sqrt(mean((valData$Weighted.Average - as.vector(predictions.12$pred))^2))
#rmseFull.9 = sqrt(mean((valData$Weighted.Average - as.vector(predictionsFull.9$pred))^2))
#rmseFull.10 = sqrt(mean((valData$Weighted.Average - as.vector(predictionsFull.10$pred))^2))
#rmseFull.11 = sqrt(mean((valData$Weighted.Average - as.vector(predictionsFull.11$pred))^2))
#rmseFull.12 = sqrt(mean((valData$Weighted.Average - as.vector(predictionsFull.12$pred))^2))

#cat("MA(9) Model RMSE:",round(rmse.9,2),"\n")
#cat("MA(10) Model RMSE:",round(rmse.10,2),"\n")
#cat("MA(11) Model RMSE:",round(rmse.11,2),"\n")
#cat("MA(12) Model RMSE:",round(rmse.12,2),"\n")
#cat("Full MA(9) Model RMSE:",round(rmseFull.9,2),"\n")
#cat("Full MA(10) Model RMSE:",round(rmseFull.10,2),"\n")
#cat("Full MA(11) Model RMSE:",round(rmseFull.11,2),"\n")
#cat("Full MA(12) Model RMSE:",round(rmseFull.12,2),"\n")


modelFullTest.11 = Arima(fullTrainRows$Weighted.Average,order=c(0,1,10),seasonal=list(order=c(1,1,1),period=52L),xreg=fullxreg)

predictions = predict(modelFullTest.11,newxreg=newxreg,n.ahead=53)

write.csv(predictions,"Data/predictions/testFullArimaPredictions.csv",row.names=FALSE)

forecast = zoo(predictions$pred,order.by=as.Date(testRows$Report.Date,format="%Y-%m-%d"))
upper = zoo(predictions$pred+1.96*predictions$se,order.by=as.Date(testRows$Report.Date,format="%Y-%m-%d"))
lower = zoo(predictions$pred-1.96*predictions$se,order.by=as.Date(testRows$Report.Date,format="%Y-%m-%d"))

rmse = sqrt(mean((testData$Weighted.Average - as.vector(predictions$pred))^2))


png(filename="Figures/fullArimaPriceForecast.png",width = 800,height=500)
plot(rep(0,nrow(testRows))~as.numeric(as.Date(testRows$Report.Date)),type="l",col="blue",ylim=c(min(min(lower),min(testData$Weighted.Average)),max(max(upper),max(testData$Weighted.Average))),
		main="Full ARIMA Predictions versus true Chuck Roll Prices",
		xlab="Date",
		ylab="Price (in Dollars)",
		lwd=2,
		xaxt='n')
axis(1,at=c(as.numeric(as.Date(testRows[3,1])),as.numeric(as.Date(testRows[11,1])),as.numeric(as.Date(testRows[19,1])),as.numeric(as.Date(testRows[26,1])),as.numeric(as.Date(testRows[34,1])),as.numeric(as.Date(testRows[41,1])),as.numeric(as.Date(testRows[48,1]))),labels=c("Apr 2018","June 2018","Aug 2018","Sep 2018","Dec 2018","Feb 2019","Apr 2019"))
polygon(c(rev(as.Date(testRows$Report.Date)), as.Date(testRows$Report.Date)), c(rev(predictions$pred+1.96*predictions$se),predictions$pred-1.96*predictions$se), col = 'grey80', border = NA)
lines(forecast,type="l",col="blue",lwd=2)
lines(testData$Weighted.Average,type="l",col="red",lwd=2)
lines(upper,type="l",col="black",lwd=2)
lines(lower,type="l",col="black",lwd=2)
legend("bottomleft",legend=c("Price Predictions","True Prices","95% Confidence"),col=c("blue","red","grey80"),lwd=10)
legend("bottomright",legend=c(paste("RMSE:",round(rmse,2)),paste0("In 95% Conf. Inv: ",round(100*sum((testData$Weighted.Average > as.vector(predictions$pred-1.96*predictions$se) & testData$Weighted.Average < as.vector(predictions$pred+1.96*predictions$se)))/length(predictions$pred)),"%"),paste0("S.E.:",round(mean(predictions$se),2))))
dev.off()
