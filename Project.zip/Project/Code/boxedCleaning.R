forumlatedChoice = read.csv("Data/rawData/rawFormulatedChoiceBoxed.csv")
formulatedSelect = read.csv("Data/rawData/rawFormulatedSelectBoxed.csv")
negotiatedChoice = read.csv("Data/rawData/rawNegotiatedChoiceBoxed.csv")
negotiatedSelect = read.csv("Data/rawData/rawNegotiatedSelectBoxed.csv")

cat("Read data in. Beginning cleaning. \n")

forumlatedChoice$Type = rep("Choice",nrow(forumlatedChoice))
formulatedSelect$Type = rep("Select",nrow(formulatedSelect))
negotiatedChoice$Type = rep("Choice",nrow(negotiatedChoice))
negotiatedSelect$Type = rep("Select",nrow(negotiatedSelect))

forumlatedChoice$Contract = rep("Formulated",nrow(forumlatedChoice))
formulatedSelect$Contract = rep("Formulated",nrow(formulatedSelect))
negotiatedChoice$Contract = rep("Negotiated",nrow(negotiatedChoice))
negotiatedSelect$Contract = rep("Negotiated",nrow(negotiatedSelect))



boxedDataBase = rbind(forumlatedChoice,formulatedSelect,negotiatedChoice,negotiatedSelect)

boxedDataBase$Weighted.Average = as.numeric(gsub(",","",boxedDataBase$Weighted.Average))
boxedDataBase$Price.Range.Low = as.numeric(gsub(",","",boxedDataBase$Price.Range.Low))
boxedDataBase$Price.Range.High = as.numeric(gsub(",","",boxedDataBase$Price.Range.High))
boxedDataBase$Total.Pounds = as.numeric(gsub(",","",boxedDataBase$Total.Pounds))
boxedDataBase = boxedDataBase[which(is.na(boxedDataBase$Weighted.Average) != T),] 



cat("Cleaning done. Dataset saved as Data/cleanedData/boxedDataset.csv \n")

write.csv(boxedDataBase,"Data/cleanedData/boxedDataset.csv",row.names=FALSE)