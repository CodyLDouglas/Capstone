fedHeifers = read.csv("Data/rawData/rawFedHeifers.csv")
fedSteer = read.csv("Data/rawData/rawFedSteer.csv")
fedBulls = read.csv("Data/rawData/rawFedBulls.csv")
fedCows = read.csv("Data/rawData/rawFedCows.csv")
cat("Read Data in. \n")
fedHeifers = fedHeifers[which( fedHeifers[,1] != "Location" ),-ncol(fedHeifers)]
fedSteer = fedSteer[which( fedSteer[,1] != "Location" ),-ncol(fedSteer)]
fedBulls = fedBulls[which( fedBulls[,1] != "Location" ),-ncol(fedBulls)]
fedCows = fedCows[which( fedCows[,1] != "Location" ),-ncol(fedCows)]
cat("Removed table headers. \n")
for(row in 1:nrow(fedHeifers)){
	if(fedHeifers[row, "Grade.Description"]=="Choice and Prime 2 3"){
		fedHeifers[row, "Quality"] = 1
	}
	if(fedHeifers[row, "Grade.Description"]=="Choice and Prime 3 4"){
		fedHeifers[row, "Quality"] = 1.5
	}
	if(fedHeifers[row, "Grade.Description"]=="Choice 2 3"){
		fedHeifers[row, "Quality"] = 2
	}
	if(fedHeifers[row, "Grade.Description"]=="Choice 2 4"){
		fedHeifers[row, "Quality"] = 2.5
	}
	if(fedHeifers[row, "Grade.Description"]=="Select and Choice 1 2"){
		fedHeifers[row, "Quality"] = 3
	}
	if(fedHeifers[row, "Grade.Description"]=="Select and Choice 2 3"){
		fedHeifers[row, "Quality"] = 3.5
	}
	if(fedHeifers[row, "Grade.Description"]=="Select 1 2"){
		fedHeifers[row, "Quality"] = 4
	}
	if(fedHeifers[row, "Grade.Description"]=="Select 2 3"){
		fedHeifers[row, "Quality"] = 4.5
	}
	if(fedHeifers[row, "Grade.Description"]=="Standard 1 2"){
		fedHeifers[row, "Quality"] = 5
	}
}
cat("Heifers, done. \n")
for(row in 1:nrow(fedSteer)){
	if(fedSteer[row, "Grade.Description"]=="Choice and Prime 2 3"){
		fedSteer[row, "Quality"] = 1
	}
	if(fedSteer[row, "Grade.Description"]=="Choice and Prime 3 4"){
		fedSteer[row, "Quality"] = 1.5
	}
	if(fedSteer[row, "Grade.Description"]=="Choice 2 3"){
		fedSteer[row, "Quality"] = 2
	}
	if(fedSteer[row, "Grade.Description"]=="Choice 2 4"){
		fedSteer[row, "Quality"] = 2.5
	}
	if(fedSteer[row, "Grade.Description"]=="Select and Choice 1 2"){
		fedSteer[row, "Quality"] = 3
	}
	if(fedSteer[row, "Grade.Description"]=="Select and Choice 2 3"){
		fedSteer[row, "Quality"] = 3.5
	}
	if(fedSteer[row, "Grade.Description"]=="Select 1 2"){
		fedSteer[row, "Quality"] = 4
	}
	if(fedSteer[row, "Grade.Description"]=="Select 2 3"){
		fedSteer[row, "Quality"] = 4.5
	}
	if(fedSteer[row, "Grade.Description"]=="Standard 1 2"){
		fedSteer[row, "Quality"] = 5
	}
}
cat("Steer, done. \n")
for(row in 1:nrow(fedBulls)){
	if(fedBulls[row, "Grade.Description"]=="Y.G. 1"){
		fedBulls[row, "Quality"] = 1
	}
	if(fedBulls[row, "Grade.Description"]=="Y.G. 1 2"){
		fedBulls[row, "Quality"] = 1.5
	}
	if(fedBulls[row, "Grade.Description"]=="Y.G. 1 3"){
		fedBulls[row, "Quality"] = 2
	}
	if(fedBulls[row, "Grade.Description"]=="Y.G. 2"){
		fedBulls[row, "Quality"] = 2.5
	}
	if(fedBulls[row, "Grade.Description"]=="Y.G. 3"){
		fedBulls[row, "Quality"] = 3
	}
	if(fedBulls[row, "Grade.Description"]=="Y.G. 4"){
		fedBulls[row, "Quality"] = 4
	}
	if(fedBulls[row, "Grade.Description"]=="Y.G. 5"){
		fedBulls[row, "Quality"] = 5
	}
}
cat("Bulls, done. \n")
for(row in 1:nrow(fedCows)){
	if(fedCows[row, "Grade.Description"]=="Breakers 75 80"){
		fedCows[row, "Quality"] = 1
	}
	if(fedCows[row, "Grade.Description"]=="Boners 80 85"){
		fedCows[row, "Quality"] = 2
	}
	if(fedCows[row, "Grade.Description"]=="Lean 85 90"){
		fedCows[row, "Quality"] = 3
	}
	if(fedCows[row, "Grade.Description"]=="Commercial 70 75"){
		fedCows[row, "Quality"] = 4
	}
	if(fedCows[row, "Grade.Description"]=="Commercial 65 70"){
		fedCows[row, "Quality"] = 5
	}
}
cat("Cows, done. \n")

fedCattleDataset = rbind(fedSteer,fedHeifers,fedBulls,fedCows)

cat("Full fed cattle dataset saved to Data/cleanedData/fedCattleDataset.csv \n")

write.csv(fedCattleDataset,"Data/cleanedData/fedCattleDataset.csv",row.names=FALSE)



feederSteers = read.csv("Data/rawData/rawFeederSteers.csv")

feederSteers = feederSteers[which(feederSteers[,1] != "Location"),-ncol(feederSteers)]

write.csv(feederSteers,"Data/cleanedData/feederSteers.csv",row.names=FALSE)