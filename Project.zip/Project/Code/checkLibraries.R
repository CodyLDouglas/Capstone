pkgs = c("xts","forecast","dynlm")

for(x in pkgs){
	if(x %in% rownames(installed.packages()) == FALSE){
		install.packages(x, repos='http://cran.us.r-project.org')
	}
}
