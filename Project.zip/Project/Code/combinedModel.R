valLinearPreds = read.csv("Data/predictions/valLinearPredictions.csv")
valFullPreds = read.csv("Data/predictions/valFullArimaPredictions.csv")
testLinearPreds = read.csv("Data/predictions/testLinearPredictions.csv")
testFullPreds = read.csv("Data/predictions/testFullArimaPredictions.csv")
fullDataset = read.csv("Data/fullDataset.csv")
valData = fullDataset[(nrow(fullDataset)-208):(nrow(fullDataset)-53),]
testData = fullDataset[(nrow(fullDataset)-52):nrow(fullDataset),]

names(valLinearPreds) = c("pred","lower","upper")
names(testLinearPreds) = c("pred","lower","upper")


valFullPreds$upper = valFullPreds$pred + 1.96*valFullPreds$se
valFullPreds$lower = valFullPreds$pred - 1.96*valFullPreds$se
testFullPreds$upper = testFullPreds$pred + 1.96*testFullPreds$se
testFullPreds$lower = testFullPreds$pred - 1.96*testFullPreds$se

avgPreds = .5 * testLinearPreds$pred + .5 * testFullPreds$pred
avgUpper = .5 * testLinearPreds$upper + .5 * testFullPreds$upper
avgLower = .5 * testLinearPreds$lower + .5 * testFullPreds$lower

rmse = sqrt(mean((testData$Weighted.Average - avgPreds)^2))



png(filename="Figures/combinedPriceForecast.png",width = 800,height=500)
plot(rep(0,nrow(testData))~as.numeric(as.Date(testData$Report.Date)),col="blue",type="l",ylim=c(min(avgLower,.9*min(testData$Weighted.Average)),max(avgUpper,max(testData$Weighted.Average))),
    main="Combined Model Predictions versus true Chuck Roll Prices",
    xlab="Date",
    ylab="Price (in Dollars)",
    lwd=2,
    xaxt='n'
    )
axis(1,at=c(as.numeric(as.Date(testData[3,1])),as.numeric(as.Date(testData[11,1])),as.numeric(as.Date(testData[19,1])),as.numeric(as.Date(testData[26,1])),as.numeric(as.Date(testData[34,1])),as.numeric(as.Date(testData[41,1])),as.numeric(as.Date(testData[48,1]))),labels=c("Apr 2018","June 2018","Aug 2018","Sep 2018","Dec 2018","Feb 2019","Apr 2019"))
polygon(c(rev(as.numeric(as.Date(testData$Report.Date))), as.numeric(as.Date(testData$Report.Date))), c(rev(avgUpper),avgLower), col = 'grey80', border = NA)
lines(avgPreds~as.numeric(as.Date(testData$Report.Date)),col="blue",lwd=2)
lines(testData$Weighted.Average~as.numeric(as.Date(testData$Report.Date)),col="red",lwd=2)
lines(avgUpper~as.numeric(as.Date(testData$Report.Date)),col="black",lwd=2)
lines(avgLower~as.numeric(as.Date(testData$Report.Date)),col="black",lwd=2)
legend("bottomleft",legend=c("Price Predictions","True Prices","95% Confidence"),col=c("blue","red","grey80"),lwd=10)
legend("bottomright",legend=c(paste("RMSE:",round(rmse,2)),paste0("In 95% Conf. Inv: ",round(100*sum((testData$Weighted.Average > avgLower & testData$Weighted.Average < avgUpper))/nrow(testData)),"%"),paste0("S.E.: ",round(mean(avgUpper-avgPreds)/1.96,2))))
dev.off()

