CREATE TABLE IF NOT EXISTS fedCattle(
	Location					TEXT NOT NULL,
	"Report.Date"				DATE NOT NULL,
	"Class.Description"			TEXT NOT NULL,
	"Selling.Basis.Description"	TEXT NOT NULL,
	"Grade.Description"			TEXT NOT NULL,
	"Head.Count"				INTEGER NOT NULL,
	"Weight.Range.Low"			INTEGER NOT NULL,
	"Weight.Range.High"			INTEGER NOT NULL,
	"Weighted.Average"			REAL NOT NULL,
	"Price.Low"					REAL NOT NULL,
	"Price.High"				REAL NOT NULL,
	"Average.Price"				REAL NOT NULL,
	"Comments"					TEXT NOT NULL,
	"Quality"					REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS feederSteers(
	Location					TEXT NOT NULL,
	"Report.Date"				DATE NOT NULL,
	"Class.Description"			TEXT NOT NULL,
	"Selling.Basis.Description"	TEXT NOT NULL,
	"Grade.Description"			TEXT NOT NULL,
	"Head.Count"				INTEGER NOT NULL,
	"Weight.Range.Low"			INTEGER NOT NULL,
	"Weight.Range.High"			INTEGER NOT NULL,
	"Weighted.Average"			REAL NOT NULL,
	"Price.Low"					REAL NOT NULL,
	"Price.High"				REAL NOT NULL,
	"Average.Price"				REAL NOT NULL,
	"Comments"					TEXT NOT NULL

);

CREATE TABLE IF NOT EXISTS boxedPrices(
	"Report.Date"		DATE NOT NULL,
	"Item.Description"	TEXT NOT NULL,
	"Total.Pounds"		INTEGER NOT NULL,
	"Price.Range.Low"	INTEGER NOT NULL,
	"Price.Range.High"	INTEGER NOT NULL,
	"Weighted.Average"	REAL NOT NULL,
	"Type"				TEXT NOT NULL,
	"Contract"			TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cornPrices(
	"Report.Date"		DATE NOT NULL,
	"Location"			TEXT NOT NULL,
	"Class"				TEXT NOT NULL,
	"Variety"			TEXT NOT NULL,
	"Grade.Description"	TEXT NOT NULL,
	"Units"				TEXT NOT NULL,
	"Transmode"			TEXT NOT NULL,
	"Bid.Low"			REAL NOT NULL,
	"Bid.High"			REAL NOT NULL,
	"Pricing.Point"		TEXT NOT NULL,
	"Delivery.Period"	TEXT NOT NULL
);

.headers on
.mode csv
.import Data/cleanedData/fedCattleDataset.csv --skip 1 fedCattle
.import Data/cleanedData/feederSteers.csv --skip 1 feederSteers
.import Data/cleanedData/boxedDataset.csv --skip 1 boxedPrices
.import Data/rawData/rawCornPrices.csv --skip 2 cornPrices