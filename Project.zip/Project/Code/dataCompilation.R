library(dplyr)
library(zoo)

steerResults = read.csv("Data/modelData/steersResults.csv")
heifersResults = read.csv("Data/modelData/heifersResults.csv")
cowsResults = read.csv("Data/modelData/cowsResults.csv")
bullsResults = read.csv("Data/modelData/bullsResults.csv")
feederResults = read.csv("Data/modelData/feederResults.csv")
chuckPrices = read.csv("Data/modelData/chuckRollPrices.csv")
cpi = read.csv("Data/economicData/CPI.csv")
porkPrices = read.csv("Data/economicData/porkChopPrices.csv")
chickenPrices = read.csv("Data/economicData/chickenPrices.csv")
expenditures = read.csv("Data/economicData/consumerExpenditures.csv")
corn = read.csv("Data/modelData/cornPrices.csv")



economic = merge(cpi,merge(porkPrices,chickenPrices,by="DATE"),by="DATE")
economic$DATE = trimws(format(as.Date(economic$DATE,format="%m/%d/%Y"),"%Y-%m-%d"))
expenditures$DATE = trimws(format(as.Date(expenditures$DATE,format="%m/%d/%Y"),"%Y-%m-%d"))

economic$EXPENDITURES = 0
for(i in 1:nrow(expenditures)){
	for(j in 1:nrow(economic))
		if(substr(expenditures[i,"DATE"],1,7)==substr(economic[j,"DATE"],1,7) | substr(expenditures[i,"DATE"],1,7)==substr(as.Date(economic[j,"DATE"])+ 31,1,7) | substr(expenditures[i,"DATE"],1,7)==substr(as.Date(economic[j,"DATE"])-30,1,7)){
			economic[j,"EXPENDITURES"] = expenditures[i,"EXPENDITURES"]
		}
}

names(economic) = c("DATE","cpi","pork","chicken","expenditures")

fullResults = merge(steerResults,merge(heifersResults,merge(cowsResults,merge(bullsResults,merge(feederResults,corn,by="Report.Date",all=TRUE),by="Report.Date"),by="Report.Date"),by="Report.Date"),by="Report.Date")
fullResults$Report.Date = trimws(format(as.Date(fullResults$Report.Date,format="%Y/%m/%d")+2,"%Y-%m-%d"))
chuckPrices$Report.Date = trimws(format(as.Date(chuckPrices$Report.Date,format="%m/%d/%Y"),"%Y-%m-%d"))
fullResults$DATE = paste0(substr(fullResults$Report.Date,1,7),"-01")

fullDataset = merge(unique(merge(chuckPrices,fullResults,by="Report.Date")),economic,by="DATE")
fullDataset = fullDataset[,-1]

fullDataset$Corn.Price = na.approx(fullDataset$Corn.Price,na.rm = FALSE)
fullDataset$Corn.Price[1] = mean(fullDataset$Corn.Price[2:52]) 


CPI2023 = 308.742

fullDataset$Weighted.Average = fullDataset$Weighted.Average*(CPI2023/fullDataset$cpi)
fullDataset$Steers.Weighted.Average.Price = fullDataset$Steers.Weighted.Average.Price*(CPI2023/fullDataset$cpi)
fullDataset$Heifers.Weighted.Average.Price = fullDataset$Heifers.Weighted.Average.Price*(CPI2023/fullDataset$cpi)
fullDataset$Cows.Weighted.Average.Price = fullDataset$Cows.Weighted.Average.Price*(CPI2023/fullDataset$cpi)
fullDataset$Bulls.Weighted.Average.Price = fullDataset$Bulls.Weighted.Average.Price*(CPI2023/fullDataset$cpi)
fullDataset$Feeder.Weighted.Average.Price = fullDataset$Feeder.Weighted.Average.Price*(CPI2023/fullDataset$cpi)
fullDataset$pork = fullDataset$pork*(CPI2023/fullDataset$cpi)
fullDataset$chicken = fullDataset$chicken*(CPI2023/fullDataset$cpi)
fullDataset$expenditures = fullDataset$expenditures*(CPI2023/fullDataset$cpi)
fullDataset$Corn.Price = fullDataset$Corn.Price*(CPI2023/fullDataset$cpi)
fullDataset$jan = ifelse(fullDataset$Month == 1, 1,0)
fullDataset$feb = ifelse(fullDataset$Month == 2, 1,0)
fullDataset$mar = ifelse(fullDataset$Month == 3, 1,0)
fullDataset$apr = ifelse(fullDataset$Month == 4, 1,0)
fullDataset$may = ifelse(fullDataset$Month == 5, 1,0)
fullDataset$jun = ifelse(fullDataset$Month == 6, 1,0)
fullDataset$jul = ifelse(fullDataset$Month == 7, 1,0)
fullDataset$aug = ifelse(fullDataset$Month == 8, 1,0)
fullDataset$sep = ifelse(fullDataset$Month == 9, 1,0)
fullDataset$oct = ifelse(fullDataset$Month == 10, 1,0)
fullDataset$nov = ifelse(fullDataset$Month == 11, 1,0)
fullDataset$dec = ifelse(fullDataset$Month == 12, 1,0)
fullDataset$season = ifelse(fullDataset$Month %in% c(12,1,2), 1, ifelse(fullDataset$Month %in% c(3,4,5),2,ifelse(fullDataset$Month %in% c(6,7,8),3,4)))
fullDataset$winter = ifelse(fullDataset$season == 1, 1, 0)
fullDataset$spring = ifelse(fullDataset$season == 2, 1, 0)
fullDataset$summer = ifelse(fullDataset$season == 3, 1, 0)
fullDataset$autumn = ifelse(fullDataset$season == 4, 1, 0)


write.csv(fullDataset,"Data/fullDataset.csv",row.names=FALSE)