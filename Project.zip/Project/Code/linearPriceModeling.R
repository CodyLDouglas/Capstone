library(xts)
library(dynlm)
library(MASS)
set.seed(1234)
fullDataset = read.csv("Data/fullDataset.csv")

testRows = fullDataset[(nrow(fullDataset)-52):nrow(fullDataset),]
indicies = sample(1:(nrow(fullDataset)-52),round(.7*nrow(fullDataset)))
trainRows = fullDataset[indicies,]
valRows = fullDataset[-indicies,]
combinedValRows = fullDataset[(nrow(fullDataset)-208):(nrow(fullDataset)-53),]

trainData = zoo(trainRows[,-1],order.by=as.Date(trainRows[,1],format="%Y-%m-%d"))
valData = zoo(valRows[,-1],order.by=as.Date(valRows[,1],format="%Y-%m-%d"))
testData = zoo(testRows[,-1],order.by=as.Date(testRows[,1],format="%Y-%m-%d"))
valCombinedData = zoo(combinedValRows[,-1],order.by=as.Date(combinedValRows[,1],format="%Y-%m-%d"))

model.1 = dynlm(Weighted.Average ~	L(Steers.Weighted.Average.Price,0)+L(Steers.Weighted.Average.Price,1)+L(Steers.Weighted.Average.Price,3)+L(Steers.Weighted.Average.Price,4)+L(Steers.Weighted.Average.Price,35)+
									L(Heifers.Weighted.Average.Price,0)+L(Heifers.Weighted.Average.Price,1)+L(Heifers.Weighted.Average.Price,3)+L(Heifers.Weighted.Average.Price,4)+L(Heifers.Weighted.Average.Price,37)+
									L(Cows.Weighted.Average.Price,19)+L(Cows.Weighted.Average.Price,28)+L(Cows.Weighted.Average.Price,45)+
									L(Bulls.Weighted.Average.Price,18)+L(Bulls.Weighted.Average.Price,28)+L(Bulls.Weighted.Average.Price,45)+
									L(Feeder.Weighted.Average.Price,0)+L(Feeder.Weighted.Average.Price,1)+L(Feeder.Weighted.Average.Price,8)+L(Feeder.Weighted.Average.Price,47)+
									L(Steers.Total.Heads,1)+L(Heifers.Total.Heads,1)+L(Heifers.Total.Heads,40)+L(Bulls.Total.Heads,44)+L(Feeder.Total.Heads,0)+L(Feeder.Total.Heads,20)+L(Feeder.Total.Heads,21)+
									L(cpi,0)+L(pork,0)+L(pork,1)+L(pork,12)+L(pork,27)+L(chicken,6)+L(chicken,26)+L(chicken,42)+L(Corn.Price,12)+L(Corn.Price,13)+jan+feb+mar+apr+may+jun+jul+aug+sep+oct+nov+dec,
									data=trainRows)
summary(model.1)

predictions = predict(model.1,valRows,interval="confidence",level=0.95)

rmse = sqrt(mean((valRows$Weighted.Average - predictions[,1])^2))
cat("Full Model RMSE: \n")
print(rmse)



#model.2 = stepAIC(model.1)

#summary(model.2)

# Model.2 is the resulting model of the step aic of model 1.

model.2 = dynlm(Weighted.Average ~	L(Steers.Weighted.Average.Price,4)+L(Steers.Weighted.Average.Price,35)+L(Heifers.Weighted.Average.Price,37)+
									L(Cows.Weighted.Average.Price,28)+L(Bulls.Weighted.Average.Price,18)+L(Bulls.Weighted.Average.Price,28)+
									L(Feeder.Weighted.Average.Price,8)+L(Feeder.Weighted.Average.Price,47)+
									L(Heifers.Total.Heads,40)+L(chicken,26)+L(chicken,42)+L(Corn.Price,12)+L(Corn.Price,13)+jan+feb+apr+may+jun+jul+aug+oct+nov+dec,
									data=trainData)


summary(model.2)

predictions = predict(model.2,valRows,interval="confidence",level=0.95)
predictionsCombined = predict(model.2,valCombinedData,interval="confidence",level=0.95)
write.csv(predictionsCombined,"Data/predictions/valLinearPredictions.csv",row.names=FALSE)

rmse = sqrt(mean((valData$Weighted.Average - predictions[,1])^2))
cat("Reduced Model RMSE: \n")
print(rmse)

model.2Full = dynlm(Weighted.Average ~	L(Steers.Weighted.Average.Price,4)+L(Steers.Weighted.Average.Price,35)+L(Heifers.Weighted.Average.Price,37)+
									L(Cows.Weighted.Average.Price,28)+L(Bulls.Weighted.Average.Price,18)+L(Bulls.Weighted.Average.Price,28)+
									L(Feeder.Weighted.Average.Price,8)+L(Feeder.Weighted.Average.Price,47)+
									L(Heifers.Total.Heads,40)+L(chicken,26)+L(chicken,42)+L(Corn.Price,12)+L(Corn.Price,13)+jan+feb+apr+may+jun+jul+aug+oct+nov+dec,
									data=combinedValRows)

predictions = predict(model.2Full,testRows,interval="confidence",level=0.95)

write.csv(predictions,"Data/predictions/testLinearPredictions.csv",row.names=FALSE)

png(filename="Figures/reducedLinearPriceForecast.png",width = 800,height=500)
plot(rep(0,nrow(testRows))~as.Date(testRows$Report.Date),col="blue",type="l",ylim=c(min(predictions[,2],.9*min(testData$Weighted.Average)),max(predictions[,3],max(testData$Weighted.Average))),
		main="Reduced Linear Model Predictions versus True Chuck Roll Prices",
		xlab="Date",
		ylab="Price (in Dollars)",
		lwd=2,
		xaxt='n'
		)
axis(1,at=c(as.numeric(as.Date(testRows[3,1])),as.numeric(as.Date(testRows[11,1])),as.numeric(as.Date(testRows[19,1])),as.numeric(as.Date(testRows[26,1])),as.numeric(as.Date(testRows[34,1])),as.numeric(as.Date(testRows[41,1])),as.numeric(as.Date(testRows[48,1]))),labels=c("Apr 2018","June 2018","Aug 2018","Sep 2018","Dec 2018","Feb 2019","Apr 2019"))
polygon(c(rev(as.Date(testRows$Report.Date)), as.Date(testRows$Report.Date)), c(rev(predictions[ ,3]), predictions[ ,2]), col = 'grey80', border = NA)
lines(as.Date(testRows$Report.Date), predictions[ ,3], col = 'black',lwd=2)
lines(as.Date(testRows$Report.Date), predictions[ ,2], col = 'black',lwd=2)
lines(predictions[,1]~as.Date(testRows$Report.Date),type="l",col="blue",lwd=2)
lines(testData$Weighted.Average~as.Date(testRows$Report.Date),type="l",col="red",lwd=2)
legend("bottomleft",legend=c("Price Predictions","True Prices","95% Confidence"),col=c("blue","red","grey80"),lwd=10)
legend("bottomright",legend=c(paste("RMSE:",round(rmse,2)),paste0("In 95% Conf. Inv: ",round(100*sum(testRows$Weighted.Average > predictions[,2] & testRows$Weighted.Average < predictions[,3])/nrow(predictions)),"%"),paste0("S.E.: ",round(mean(predictions[,3]-predictions[,1])/1.96,2))))
dev.off()