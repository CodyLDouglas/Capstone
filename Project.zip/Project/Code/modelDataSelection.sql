
.headers on
.mode csv
.output Data/modelData/steersResults.csv
SELECT 	"Report.Date",
		SUM("Head.Count") as "Steers.Total.Heads",
		SUM("Head.Count"*"Weighted.Average")/SUM("Head.Count") as "Steers.Weighted.Average.Weight",
		SUM("Head.Count"*"Average.Price")/SUM("Head.Count") as "Steers.Weighted.Average.Price",
		SUM("Head.Count"*"Quality")/SUM("Head.Count") as "Steers.Weighted.Average.Quality"
FROM fedCattle
GROUP BY "Class.Description","Report.Date"
HAVING SUM("Head.Count") != 0 AND "Class.Description" LIKE "Slaughter Steers"
;

.output Data/modelData/heifersResults.csv
SELECT 	"Report.Date",
		SUM("Head.Count") as "Heifers.Total.Heads",
		SUM("Head.Count"*"Weighted.Average")/SUM("Head.Count") as "Heifers.Weighted.Average.Weight",
		SUM("Head.Count"*"Average.Price")/SUM("Head.Count") as "Heifers.Weighted.Average.Price",
		SUM("Head.Count"*"Quality")/SUM("Head.Count") as "Heifers.Weighted.Average.Quality"
FROM fedCattle
GROUP BY "Class.Description","Report.Date"
HAVING SUM("Head.Count") != 0 AND "Class.Description" LIKE "Slaughter Heifers"
;

.output Data/modelData/cowsResults.csv
SELECT 	"Report.Date",
		SUM("Head.Count") as "Cows.Total.Heads",
		SUM("Head.Count"*"Weighted.Average")/SUM("Head.Count") as "Cows.Weighted.Average.Weight",
		SUM("Head.Count"*"Average.Price")/SUM("Head.Count") as "Cows.Weighted.Average.Price",
		SUM("Head.Count"*"Quality")/SUM("Head.Count") as "Cows.Weighted.Average.Quality"
FROM fedCattle
GROUP BY "Class.Description","Report.Date"
HAVING SUM("Head.Count") != 0 AND "Class.Description" LIKE "Slaughter Cows"
;

.output Data/modelData/bullsResults.csv
SELECT 	"Report.Date",
		SUM("Head.Count") as "Bulls.Total.Heads",
		SUM("Head.Count"*"Weighted.Average")/SUM("Head.Count") as "Bulls.Weighted.Average.Weight",
		SUM("Head.Count"*"Average.Price")/SUM("Head.Count") as "Bulls.Weighted.Average.Price",
		SUM("Head.Count"*"Quality")/SUM("Head.Count") as "Bulls.Weighted.Average.Quality"
FROM fedCattle
GROUP BY "Class.Description","Report.Date"
HAVING SUM("Head.Count") != 0 AND "Class.Description" LIKE "Slaughter Bulls"
;

.output Data/modelData/feederResults.csv
SELECT 	"Report.Date",
		SUM("Head.Count") as "Feeder.Total.Heads",
		SUM("Head.Count"*"Weighted.Average")/SUM("Head.Count") as "Feeder.Weighted.Average.Weight",
		SUM("Head.Count"*"Average.Price")/SUM("Head.Count") as "Feeder.Weighted.Average.Price"
FROM feederSteers
GROUP BY "Report.Date"
HAVING SUM("Head.Count") != 0
;

.output Data/modelData/chuckRollPrices.csv
SELECT 	"Report.Date",
		"Total.Pounds",
		"Weighted.Average",
		SUBSTR("Report.Date",1,2) as "Month"
FROM boxedPrices
WHERE 	"Item.Description" LIKE "Chuck, roll, lxl, neck/off (116A  3)"
	AND "Type" LIKE "Choice"
	AND "Contract" LIKE "Formulated"
;

.output Data/miscData/boxedBeefStats.csv
SELECT 	"Item.Description",
		AVG("Weighted.Average") as "Average.Price",
		Min("Weighted.Average") as "Min.Price",
		MAX("Weighted.Average") as "Max.Price",
		AVG("Total.Pounds") as "Average.Quantity.Traded",
		SUM("Total.Pounds") as "Total.Quantity.Traded",
		Min("Total.Pounds") as "Min.Quantity.Traded",
		MAX("Total.Pounds") as "Max.Quantity.Traded"
FROM boxedPrices
WHERE "Type" LIKE "Choice" AND "Contract" LIKE "Formulated"
GROUP BY "Item.Description"
;

.output Data/modelData/cornPrices.csv
SELECT 	"Report.Date",
		AVG("Bid.High") "Corn.Price"
FROM cornPrices
GROUP BY "Report.Date"
;

