data = read.csv("Data/fullDataset.csv")

summaryStats = data.frame(Variable=character(),mean=numeric(),median=numeric(),variance=numeric(),stdev=numeric())

for(i in 1:ncol(data)){
	if(class(data[,i])=="numeric"){
		Variable = names(data)[i]
		mean = round(mean(data[,i]),2)
		median =  round(median(data[,i]),2)
		variance =  round(var(data[,i]),2)
		stdev =  round(sd(data[,i]),2)
		tmp = data.frame(Variable=Variable,mean=mean,median=median,variance=variance,stdev=stdev)
		summaryStats = rbind(summaryStats, tmp)
	}
}

write.csv(summaryStats,"Data/miscData/summaryStats.csv",row.names=FALSE)