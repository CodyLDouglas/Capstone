=-=-=-=-=-=-=-=-=-=-=-=-=-=
Welcome to the Data folder
=-=-=-=-=-=-=-=-=-=-=-=-=-=

This folder contains all the data, raw and manipulated, used in this project. For more information and references on the data, see Appendix I and the references section in Paper.pdf, in the main Project folder. If you have not seen the ReadMe in the Code/ folder, I reccomend reading that first.

rawData-
	This subfolder contains all the raw data obtained from the USDA AMS Market News online service. This data contains the cattle auction results and conr prices.

economicData-
	This subfolder contains all the econonmic variables aquired from the FRED used in this project. Including CPI and personal consumer expenditures as well as the retail prices of chicken breasts and pork.

cleanedData-
	This subfolder contains the output of Code/cattleCleaning.R and Code/boxedCleaning.R. This data has been cleaned (e.g. removed headers within the body of the data, converted quality scores to a single numerical system, and combining like types together.). This data is the input into the SQL database.

modelData-
	This subfolder contains the output of Code/modelDataSelection.sql, pulling the necessary variables used in the modeling process. This data is combined by Code/dataCompilation.R, and saved as fullDataset.csv.

predictions-
	This subfolder contains the forecasts made by the models used in this porject. Saved to be combined in the composite forecast.

miscData-
	This subfolder contains summary statistics data for the boxed beef and cattle data.

database.db-
	The SQL database containing the cleaned data created previously.

fullDataset.csv-
	The full dataset used in the modeling process.

fullDiffs.csv-
	The first differences of the data in fullDataset.csv, used to create the CCF, ACF, and PACF plots in Figures/.