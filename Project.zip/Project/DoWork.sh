chmod +x Code/Compile.sh
chmod +x Paper/Compile.sh
rm Paper.pdf
./Code/Compile.sh
echo "Beginning Paper."
cd Paper
./Compile.sh
mv Paper.pdf ../Paper.pdf
echo "All Done. Finished paper can be located in this directory titled Paper.pdf"
