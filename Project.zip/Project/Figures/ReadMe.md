=-=-=-=-=-=-=-=-=-=-=-=-=-=
Welcome to the Code folder
=-=-=-=-=-=-=-=-=-=-=-=-=-=

This folder contains all figures produced by the code in the Code/ folder. If you have not seem Code/ReadMe.md, I would reccomend reading that first. Now, a breakdown of the figures.

acfs-
	This subfolder contains the ACFs and PACFs of the wholesale chuck roll prices and price differences used in this project. The ACF plots show the correlation of the data points and the previous x values, while a PACF shows the correlation between the data points and the value x periods back and controls for the lags in between.

ccfs-
	This subfolder contains a plethora of plots that display the crosscorrelations functions (CCFs) between chuck and other variables. CCFs represent the correlation between data points of one time series, and the lagged values of another. These plots show the ccfs of the first differences in the variables. The name of these pngs explain what two variables are being compared in the plot. If there is just one variable name, it is the CCF between that variable and chuck prices, while if it has the name of two variables, it is the CCF of those two. For example, steersBullsACF.png is the ccf between the steers and bulls price differences, and steersACF.png is the CCF between steers and chuck price differences.

timeSeriesPlots-
	This subfolder simply shows a line graph of the variables used in the project, and all prices are in 2023 dollars.

fullArimaPriceForecast-
	This is the final generated forecast of the ARIMA model created in the project.

combinedPriceForecast-
	This is the final generated forecast of the combined model created in the project, which is a 50/50 weighting of the ARIMA and linear forecasts.

reducedLinearPriceForecast-
	This is the final generated forecast of the reduced linear model created in the project.