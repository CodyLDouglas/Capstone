pdflatex outline
biber outline
pdflatex outline
pdflatex outline

mv outline.pdf ../outline.pdf