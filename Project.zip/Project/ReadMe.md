=-=-=-=-=-=-=-=-=
Capstone Project
Cody Douglas
July, 26th 2024
=-=-=-=-=-=-=-=-=

This is my final project, capping off the one year Master's in Business Analytics Program at the Universirt of Central Florida. In this folder you will see many subdirectories that contain the output of this project. The Code/ and Figures/ folder have its own ReadMe that I would suggest taking a look at before executing the code. Also in this directory, you will see 4 pdf files titled like CDouglasX.pdf, these are a timeline of the project of sorts along with outline.pdf which was the original framework of the project.

Once ready to execute the code, navigate to this directory in the command line, then type ./DoWork.sh, after which the code will start executing. Once the code is done, the final paper will appear in this directory, titled Paper.pdf.

Other miscellaneous files within this Project folder.

chicago.bst-
	A LaTeX bibliography style file created by Glenn Paulley in 1992. This allows the paper to follow the chicago style guide in references.

references.bib-
	The bibliography file for the paper.

Tables-
	This subfolder contains the tables of results from the Code for the paper.

Paper-
	This subfolder contains the LaTeX .tex files that create the body of the paper.