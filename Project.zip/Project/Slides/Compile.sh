pdflatex slides
biber slides
pdflatex slides
pdflatex slides

mv slides.pdf ../CDouglasPresentation4.pdf